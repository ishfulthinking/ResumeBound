<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="city2" tilewidth="16" tileheight="16" margin="1" tilecount="1131" columns="39">
 <image source="../../../media/roguelike-modern-city-pack/Spritesheet/roguelikeCity_transparent.png" trans="ff00ff" width="628" height="475"/>
</tileset>
